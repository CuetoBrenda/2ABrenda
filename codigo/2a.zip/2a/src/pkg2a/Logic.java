/*
 * Class Logic
 * @author Brenda 
 *
 * Copyright (c) 2022-2023 UV. All Rights Reserved.
 */

/**
 * Clase logica, en la cual se instancian y 
 * ejecutan todas las clases del programa 2a.
 *
 * @version 09.06.2022
 * @author brenda cueto
 */
public class Logic {

    private int n;
    private String data;
    private String[] arrData;
    private int lCounter;
    public int mCounter;

    public Logic() {
    }

    public void logic2a() {
        
        Input myInput = new Input();
        Output myOut = new Output();
        
		Data myData = new Data();
		LineCounter myLCounter = new LineCounter();
		MethodCounter myMCounter = new MethodCounter();

        data = myInput.readData("C:\\Users\\brend\\Documents\\NetBeansProjects\\2a\\src\\pkg2a\\App.java");

		arrData = myData.saveData(data);
        n = arrData.length;
        System.out.println("****************************************");
        System.out.println("    Total de Lineas  :  " + n);

        lCounter = myLCounter.countLines(arrData, n);
        System.out.println("    Lineas Logicas :  " + lCounter);

		mCounter = myMCounter.countMethods(arrData, n);
        System.out.println("\n    Total de Metodos :  " + mCounter);
        System.out.println("****************************************");

        myOut.writeData("C:\\Users\\brend\\Desktop\\2a\\resultados.txt", "Número de lineas = " + lCounter + " Múmero de metodos = " + mCounter);
    }
}