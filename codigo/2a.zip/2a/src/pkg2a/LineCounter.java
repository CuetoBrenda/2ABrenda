/*
 * Class LineCounter
 * @author brenda cueto 
 *
 * Copyright (c) 2022-2023 UV. All Rights Reserved.
 */

 /**
 * Clase de conteo de las lineas de codigo de un programa.
 *
 * @version 09.06.2022
 * @author brenda cueto
 * 
 **/

public class LineCounter {
    
    public String arrData;
    private int totalLines = 0;

    public LineCounter() {
    }

    /**
     * @param dataList 
     * @param n
     */
    public int countLines(String[] dataList, int n) {
        for(int x = 0; x<n; x++){
            arrData = dataList[x].trim();
            if (!("".equals(arrData) || arrData.startsWith("//") || arrData.startsWith("}") || arrData.startsWith("/*") || arrData.startsWith("*/") || arrData.startsWith("*"))) {
                totalLines++;
            }
        }
        return totalLines;
    }
}