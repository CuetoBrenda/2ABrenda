/*
 * Class Input
 * @author brenda cueto
 *
 * Copyright (c) 2022-2023 UV. All Rights Reserved.
 */
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * Clase para leer un documento de entrada de datos.
 *
 * @version 1.0 06 Abril 2022
 * @author brenda cueto
 */
public class Input {

	private String data;
    private BufferedReader br;

    public Input() {
    }

    /**
     * @param inFile
     */

    public String readData(String inFile) {
		try 
			{
				br = new BufferedReader(new FileReader(inFile));
				StringBuilder sb = new StringBuilder();
				String line;
				// = br.readLine();
				while ( (line = br.readLine()) != null ) 
					{
						sb.append(line);
                        sb.append(",");
					}
				data = sb.toString();
			} 
		catch (IOException e) 
			{
                System.out.println("error : " + e);
				e.printStackTrace();
			}
	
	return data;
	}
}